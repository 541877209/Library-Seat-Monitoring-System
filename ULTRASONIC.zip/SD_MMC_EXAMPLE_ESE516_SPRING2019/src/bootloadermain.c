/*******************************************************************************/
/*
 *@BootLoader@
 */
/******************************************************************************/
/************************************************************************/
/*   address                                                                   */
/************************************************************************/
#define APP_START_ADDRESS ((uint32_t)0x10000) // Must be address of start of main application
                                             //start address of application code in nvm (pointer to jump to in the application code)
/************************************************************************/
/*    Main application reset vector address                                                                  */
/************************************************************************/

#define APP_START_RESET_VEC_ADDRESS (APP_START_ADDRESS+ (uint32_t) 0x04 )



/************************************************************************/
/* Libaray                                                                     */
/************************************************************************/
#include <asf.h>
#include "conf_example.h"
#include <string.h>
#include "SerialConsole/SerialConsole.h" 
#include <crc32.h>
#include <delay.h>
#include "sd_mmc_spi.h"
void sd_mmc_deinit(void);
/*
 *state structure
 */
//! Structure for UART module connected to EDBG (used for unit test output)


/************************************************************************/
/* functions                                                                     */
/************************************************************************/
int main (void)
{
	//initialization
	system_init();
	//configure_nvm();
	delay_init();
	/*INITIALIZE SYSTEM PERIPHERALS*/
	InitializeSerialConsole();
	system_interrupt_enable_global();
 struct port_config pin_confn;
 struct port_config pin_confinputs;
 struct port_config pin_confDENGOUTPUT;
 port_get_config_defaults(&pin_confn);
 port_get_config_defaults(&pin_confinputs);
 char stringNum[20];
 SerialConsoleWriteString("\nthis is the infraded sensor code.\r\n");
 char stringinfradedNum[20];
while (1) {
		//SerialConsoleWriteString("\nthis is the weight sensor code.\n\r");
	//SerialConsoleWriteString("this is the weight sensor code.\n\r");

	    uint32_t number;
		
		
		
		bool statuss;
		 pin_confn.direction = PORT_PIN_DIR_OUTPUT;
		 pin_confDENGOUTPUT.direction = PORT_PIN_DIR_OUTPUT;
		 pin_confinputs.direction = PORT_PIN_DIR_INPUT;
		 port_pin_set_config(PIN_PB03, &pin_confn);
		 port_pin_set_config(PIN_PA02, &pin_confDENGOUTPUT);
		 port_pin_set_config(PIN_PA20, &pin_confinputs);
		// bool status=port_pin_get_input_level(PIN_PA02);	
		//port_pin_set_output_level(PIN_PA02,true);
	
		port_pin_set_output_level(PIN_PB03,false);
		delay_us(5);
		port_pin_set_output_level(PIN_PB03,true);
		delay_us(10);
		port_pin_set_output_level(PIN_PB03,false);

		SerialConsoleWriteString("if there is something\r\n");
		delay_ms(100);
		statuss=port_pin_get_input_level(PIN_PA20);
	    if(statuss==true){

		SerialConsoleWriteString("high\r\n");
		//delay_ms(100);
		number=1;
		
			sprintf(stringinfradedNum,"%d",number);
			SerialConsoleWriteString("\r\n");
			SerialConsoleWriteString(stringinfradedNum);
			SerialConsoleWriteString("\r\n");
		port_pin_set_output_level(PIN_PA02,true);
		delay_ms(100);
		port_pin_set_output_level(PIN_PA02,false);
		
		
		
		}
		else{
		SerialConsoleWriteString("low\r\n");
		number=0;
		sprintf(stringinfradedNum,"%d",number);
		SerialConsoleWriteString("\r\n");
		SerialConsoleWriteString(stringinfradedNum);
		SerialConsoleWriteString("\r\n");
		delay_ms(100);
		}
	
	
	
		//port_pin_set_output_level(PIN_PA02,true);

	
	}  
	
}


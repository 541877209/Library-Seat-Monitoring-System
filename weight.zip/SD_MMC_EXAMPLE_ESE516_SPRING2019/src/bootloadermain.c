/*******************************************************************************/
/*
 *@BootLoader@
 */
/******************************************************************************/
/************************************************************************/
/*   address                                                                   */
/************************************************************************/
#define APP_START_ADDRESS ((uint32_t)0x10000) // Must be address of start of main application
                                             //start address of application code in nvm (pointer to jump to in the application code)
/************************************************************************/
/*    Main application reset vector address                                                                  */
/************************************************************************/

#define APP_START_RESET_VEC_ADDRESS (APP_START_ADDRESS+ (uint32_t) 0x04 )



/************************************************************************/
/* Libaray                                                                     */
/************************************************************************/
#include <asf.h>
#include "conf_example.h"
#include <string.h>
#include "SerialConsole/SerialConsole.h" 
#include <crc32.h>
#include <delay.h>
#include "sd_mmc_spi.h"
void sd_mmc_deinit(void);
/*
 *state structure
 */
//! Structure for UART module connected to EDBG (used for unit test output)


/************************************************************************/
/* functions                                                                     */
/************************************************************************/



int main (void)
{

   
	//initialization
	system_init();
	//configure_nvm();
	delay_init();
	
	
	
	/*INITIALIZE SYSTEM PERIPHERALS*/
	InitializeSerialConsole();
	system_interrupt_enable_global();
	

 struct port_config pin_conf;
 struct port_config pin_confinput;
 port_get_config_defaults(&pin_conf);
 port_get_config_defaults(&pin_confinput);
 char stringNum[20];

 char stringweightNum[20];
 char stringDIFFERENCENum[20];
	while (1) {
		
		SerialConsoleWriteString("\nthis is the weight sensor code.\n\r");
	

		uint32_t Count;
		uint32_t i;
		uint32_t weight;
		uint32_t difference;
		
		 pin_conf.direction  = PORT_PIN_DIR_OUTPUT;
		 pin_confinput.direction =PORT_PIN_DIR_INPUT;
		 //OUT
		 port_pin_set_config(PIN_PA08, &pin_conf);
		 //INPUT
		 port_pin_set_config(PIN_PA02, &pin_confinput);
		// bool status=port_pin_get_input_level(PIN_PA02);
	
		 port_pin_set_output_level(PIN_PA08,false);
		 Count=0;
	

		 while(port_pin_get_input_level(PIN_PA02));

		 for (i=0;i<24;i++){
				 port_pin_set_output_level(PIN_PA08,true);
				 //	delay_ms(500);
				 Count=Count<<1;
				 port_pin_set_output_level(PIN_PA08,false);
				// 	delay_ms(500);
				 if( port_pin_get_input_level(PIN_PA02))
				 {
					 Count++;
				 }
				 }
				 port_pin_set_output_level(PIN_PA08,true);
				 //		delay_ms(500);
				 Count=Count^0x800000;

				 port_pin_set_output_level(PIN_PA08,false);
				 //		delay_ms(500);


          
        //  difference=Count-8579650;
          sprintf(stringNum,"%d",Count);
          SerialConsoleWriteString("\r\n");
          SerialConsoleWriteString(stringNum);
          SerialConsoleWriteString("\r\n");

		  
		    if (Count<8391000){
		//	SerialConsoleWriteString("ok it is less than \r\n");
		            difference=0;
		     }
			 else{
			// SerialConsoleWriteString("ok, it is larger than \r\n");
			 difference=Count-8391000;
			 }
			
			
			
			sprintf(stringDIFFERENCENum,"%d",difference);
			SerialConsoleWriteString("\r\n");
			SerialConsoleWriteString(stringDIFFERENCENum);
			SerialConsoleWriteString("\r\n");



			weight=difference*0.0005718;
			sprintf(stringweightNum,"%d",weight);
			SerialConsoleWriteString("\r\n");
			SerialConsoleWriteString(stringweightNum);
			SerialConsoleWriteString("\r\n");
			
			

	 
			 
	
			 
		 

	}  
	
}


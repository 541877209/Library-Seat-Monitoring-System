
/**************************************************************************//**
* @file        SerialConsole.c
* @ingroup 	   Serial Console
* @brief       This file has the code necessary to run the CLI and Serial Debugger. It initializes an UART channel and uses it to receive command from the user
*				as well as print debug information.
* @details     This file has the code necessary to run the CLI and Serial Debugger. It initializes an UART channel and uses it to receive command from the user
*				as well as print debug information.
*				
*				The code in this file will:
*				--Initialize a SERCOM port (SERCOM # ) to be an UART channel operating at 115200 baud/second, 8N1
*				--Register callbacks for the device to read and write characters asynchronously as required by the CLI
*				--Initialize the CLI and Debug Logger data structures
*				
*				Usage:
*		
*
* @copyright   
* @author      
* @date        January 26, 2019
* @version		0.1
*****************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "SerialConsole.h"

/******************************************************************************
* Defines
******************************************************************************/
#define RX_BUFFER_SIZE 256	///<Size of character buffer for RX, in bytes
#define TX_BUFFER_SIZE 15000	///<Size of character buffers for TX, in bytes

/******************************************************************************
* Structures and Enumerations
******************************************************************************/
cbuf_handle_t cbufRx;	///<Circular buffer handler for receiving characters from the Serial Interface
cbuf_handle_t cbufTx;	///<Circular buffer handler for transmitting characters from the Serial Interface

char latestRx;	///< Holds the latest character that was received
char latestTx;	///< Holds the latest character to be transmitted.

char new_get[100];
unsigned int counter = 0;
unsigned int MAJOR = 1;
unsigned int MINOR = 4;
unsigned int PATCH = 88;
char sub[10];


/***************************** *************************************************
*  Callback Declaration
******************************************************************************/
void usart_write_callback(struct usart_module *const usart_module);	//Callback for when we finish writing characters to UART
void usart_read_callback(struct usart_module *const usart_module);	//Callback for when we finis reading characters from UART

/******************************************************************************
* Local Function Declaration
******************************************************************************/
static void configure_usart(void);
static void configure_usart_callbacks(void);

/******************************************************************************
* Global Local Variables
******************************************************************************/
struct usart_module usart_instance;
char rxCharacterBuffer[RX_BUFFER_SIZE]; ///<Buffer to store received characters
char txCharacterBuffer[TX_BUFFER_SIZE]; ///<Buffer to store characters to be sent
enum eDebugLogLevels currentDebugLevel = LOG_INFO_LVL; ///<Variable that holds the level of debug log messages to show. Defaults to showing all debug values


/******************************************************************************
* Global Functions
******************************************************************************/



/**************************************************************************//**
* @fn			void InitializeSerialConsole(void)
* @brief		Initializes the UART - sets up the SERCOM to act as UART and registers the callbacks for
*				asynchronous reads and writes.
* @details		Initializes the UART - sets up the SERCOM to act as UART and registers the callbacks for
*				asynchronous reads and writes. 
* @note			Call from main once to initialize Hardware.
*****************************************************************************/

void InitializeSerialConsole()
{

	//Initialize circular buffers for RX and TX
	cbufRx = circular_buf_init((uint8_t*)rxCharacterBuffer, RX_BUFFER_SIZE);
	cbufTx = circular_buf_init((uint8_t*)txCharacterBuffer, TX_BUFFER_SIZE);

	//Configure USART and Callbacks
	configure_usart();
	configure_usart_callbacks();

	usart_read_buffer_job(&usart_instance, (uint8_t*) &latestRx, 1);	//Kicks off constant reading of characters

	//Add any other calls you need to do to initialize your Serial Console
}


/**************************************************************************//**
* @fn			void SerialConsoleWriteString(char * string)
* @brief		Writes a string to be written to the uart. Copies the string to a ring buffer that is used to hold the text send to the uart
* @details		Uses the ringbuffer 'cbufTx', which in turn uses the array 'txCharacterBuffer'
* @note			Use to send a string of characters to the user via UART  ?string??circular_buffer??????
*****************************************************************************/
void SerialConsoleWriteString(char * string)
{
	if(string != NULL)
	{
		for (size_t iter = 0; iter < strlen(string); iter++)
		{
			circular_buf_put(cbufTx, string[iter]);
		}
		
		if(usart_get_job_status(&usart_instance, USART_TRANSCEIVER_TX) == STATUS_OK)
		{
			circular_buf_get(cbufTx, (uint8_t*) &latestTx); //Perform only if the SERCOM TX is free (not busy)
			usart_write_buffer_job(&usart_instance, (uint8_t*) &latestTx, 1);
		}
	}
}


/**************************************************************************//**
* @fn			int SerialConsoleReadCharacter(uint8_t *rxChar)
* @brief		Reads a character from the RX ring buffer and stores it on the pointer given as an argument.
*				Also, returns -1 if there is no characters on the buffer
*				This buffer has values added to it when the UART receives ASCII characters from the terminal
* @details		Uses the ringbuffer 'cbufTx', which in turn uses the array 'txCharacterBuffer'
* @param[in]	Pointer to a character. This function will return the character from the RX buffer into this pointer
* @return		Returns -1 if there are no characters in the buffer
* @note			Use to receive characters from the RX buffer (FIFO)
*****************************************************************************/
int SerialConsoleReadCharacter(uint8_t *rxChar)
{
	return circular_buf_get(cbufRx, (uint8_t*) rxChar);  // ??circular_buffer??
}


/*
DEBUG LOGGER FUNCTIONS						
*/

/**************************************************************************//**
* @fn			eDebugLogLevels getLogLevel(void)
* @brief		Gets the level of debug to print to the console to the given argument.
*				Debug logs below the given level will not be allowed to be printed on the system
* @return		Returns the current debug level of the system.
* @note
*****************************************************************************/

enum eDebugLogLevels getLogLevel(void) 
{	
return currentDebugLevel;       //current logging level
}

/**************************************************************************//**
* @fn			eDebugLogLevels getLogLevel(void)
* @brief		Sets the level of debug to print to the console to the given argument.
*				Debug logs below the given level will not be allowed to be printed on the system
* @param[in]   debugLevel The debug level to be set for the debug logger
* @note
*****************************************************************************/
void setLogLevel(enum eDebugLogLevels debugLevel)
{
currentDebugLevel = debugLevel;   //Sets the Debug Logger level to the given level
}


/**************************************************************************//**
* @fn			LogMessage (Students to fill out this)																					
* @brief        check the current debug level and compare to the given level. If the given level is higher than 
                the debug level, than print to the screen. Otherwise, nothing printed.  
                
* @note
*****************************************************************************/

void LogMessage(enum eDebugLogLevels level, const char *format, ...)
{
	int cur_level = getLogLevel();
	if (level >= cur_level )
	{		
		va_list aptr;
		char buffer[100];
		va_start(aptr,format);
		vsprintf(buffer,format,aptr);
		va_end(aptr);
		SerialConsoleWriteString(buffer);	
	} 
};

/**************************************************************************//**
* @fn			Command Line Interface Commands
* @brief        User enter different key words and following an "Enter" space, the terminal will 
                print the message to the screen. If it is not the same as the key words, the terminal 
				will print an error message. 
				User can delete the wrong letter he or she entered. It will be printed to the terminal.
* @note
*****************************************************************************/


int flag = 0;
void CommandLineInterface(void)
{
	
	if((int)latestRx == 13)
	{
		//SerialConsoleWriteString(&new_get[0]);
		//SerialConsoleWriteString("\r\n");
		latestRx='a';
		
		if(0 == strcmp("help",new_get) ){
		char help[]="1. help\r\nDescription: Prints the bootloader firmware version\r\n2. ver_bl\r\nDescription: Prints the bootloader firmware version\r\n3. ver_app\r\nDescription: Prints the application code firmware version\r\n4. mac\r\na. Description: returns the mac address of the device\r\n5. ip\r\na. Description: returns the ip address of the device in the standard format: ex. 255.255.255.255\r\n6. devName\r\ng. Description: Returns the name of the developer (your name)\r\n7. setDeviceName <string name>\r\na. Description: Sets the name of the device to the given string\r\n\r\n";
		SerialConsoleWriteString(help);
	
		}
		else if(0 == strcmp("ver_bl",new_get)){
			char ver_bl[100];
			int j = snprintf(ver_bl,100,"ver_bl\r\nPrints the bootloader firmware version %d.%d.%d",MAJOR,MINOR,PATCH);
		    SerialConsoleWriteString(ver_bl);
		}
		else if(0 == strcmp("ver_app",new_get)){
			char ver_app[100];
			int j = snprintf(ver_app,100,"ver_app.\r\n application code firmware version: %d.%d.%d\r\n",MAJOR,MINOR,PATCH);
			SerialConsoleWriteString(ver_app);
		}
		else if(0 == strcmp("mac",new_get)){
			char mac[]="mac\r\n f.ff.ff.ff.ff.ff\r\n";
			SerialConsoleWriteString(mac);
		}
		else if(0 == strcmp("ip",new_get)){
			char ip[]="6. devName\r\n 255.255.255.255\r\n";
			SerialConsoleWriteString(ip);
		}
		else if(0 == strncmp("setDeviceName",new_get,13)){
			
				int j = 0;
				for(int i=14;i<strlen(new_get);i++){
					
						sub[i-14]=new_get[i];
						
					}	
			SerialConsoleWriteString("\r\n");
			
			char ans[19]="Device Name set to ";
			strcat(ans,sub);
			strcat(ans,"\r\n");
			SerialConsoleWriteString(ans);
			
					
				
			
		}
		else if (0 == strcmp("getDeviceName",new_get))
		{
			char getDeviceName[16]="device name is ";
			strcat(getDeviceName,sub);
			strcat(getDeviceName,"\r\n");
			SerialConsoleWriteString(getDeviceName);
		}
		else{
			char error[]="error";
			SerialConsoleWriteString(error);
			for(int i=5; i<strlen(new_get);++i){
					SerialConsoleWriteString(" ");
				
			}
			SerialConsoleWriteString("\r\n");
			
		}
		
		
		//SerialConsoleWriteString(new_get);
		//SerialConsoleWriteString("\r\n");	
		memset(new_get,0,counter);
		counter = 0 ;
		//SerialConsoleWriteString(new_get);
		//SerialConsoleWriteString("\r\n");
		//new_get = {'\0'};	
	}
	if ((int)latestRx == 8 )
	{

		
		//SerialConsoleWriteString(&latestRx);
		SerialConsoleWriteString(" ");
		//SerialConsoleWriteString(" ");
		SerialConsoleWriteString(&latestRx);
		//memset(new_get,0,counter-2);
		new_get[counter-1] = NULL;
		if (counter>0)
		{
			counter--;
		}

		latestRx='a';
		//new_get[counter] = 'p';
	
	}
	
}




/******************************************************************************
* Local Functions
******************************************************************************/

/**************************************************************************//**
* @fn			static void configure_usart(void)
* @brief		Code to configure the SERCOM "EDBG_CDC_MODULE" to be a UART channel running at 115200 8N1
* @note			
*****************************************************************************/
static void configure_usart(void)
{
	struct usart_config config_usart;
	usart_get_config_defaults(&config_usart);

	config_usart.baudrate    = 115200;
	config_usart.mux_setting = EDBG_CDC_SERCOM_MUX_SETTING;
	config_usart.pinmux_pad0 = EDBG_CDC_SERCOM_PINMUX_PAD0;
	config_usart.pinmux_pad1 = EDBG_CDC_SERCOM_PINMUX_PAD1;
	config_usart.pinmux_pad2 = EDBG_CDC_SERCOM_PINMUX_PAD2;
	config_usart.pinmux_pad3 = EDBG_CDC_SERCOM_PINMUX_PAD3;
	while (usart_init(&usart_instance,
					  EDBG_CDC_MODULE, 
					  &config_usart) != STATUS_OK) 
	{

	}
	
	usart_enable(&usart_instance);
}


/**************************************************************************//**
* @fn			static void configure_usart_callbacks(void)
* @brief		Code to register callbacks
* @note
*****************************************************************************/
static void configure_usart_callbacks(void)
{
	usart_register_callback(&usart_instance,
	usart_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&usart_instance,
	usart_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	usart_enable_callback(&usart_instance, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&usart_instance, USART_CALLBACK_BUFFER_RECEIVED);
}






/******************************************************************************
* Callback Functions
******************************************************************************/

/**************************************************************************//**
* @fn			void usart_read_callback(struct usart_module *const usart_module)
* @brief		Callback called when the system finishes receives all the bytes requested from a UART read job
* @note
*****************************************************************************/
void usart_read_callback(struct usart_module *const usart_module)
{
	if(((int)latestRx != 13)&&((int)latestRx != 8)){
		new_get[counter]=latestRx;
		counter++;
	}
	
	SerialConsoleWriteString(&latestRx);
	circular_buf_put(cbufRx, (uint8_t) latestRx); //Add the latest read character into the RX circular Buffer
	usart_read_buffer_job(&usart_instance, (uint8_t*) &latestRx, 1);	//Order the MCU to keep reading
	
}


/**************************************************************************//**
* @fn			void usart_write_callback(struct usart_module *const usart_module)
* @brief		Callback called when the system finishes sending all the bytes requested from a UART read job
* @note
*****************************************************************************/
void usart_write_callback(struct usart_module *const usart_module)
{
	if(circular_buf_get(cbufTx, (uint8_t*) &latestTx) != -1) //Only continue if there are more characters to send
	{
		usart_write_buffer_job(&usart_instance, (uint8_t*) &latestTx, 1);
	}
	
}

